using Pkg

dep = [
    "ArgParse",
    "CSV",
    "DelimitedFiles",
    "StatsBase",
    "Tables"
]

Pkg.add(dep)